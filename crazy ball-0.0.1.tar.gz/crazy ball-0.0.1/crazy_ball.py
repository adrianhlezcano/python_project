#!/usr/bin/python2.6
""" This is little game, which display a ball in a Window and 
    and the ball starts moving. """

from gasp import *


def createBall():
    ball = Circle((0, 0), 10, filled=True);
    return ball;

def moveBall(ball, x, y):
    move_to(ball, (x, y));


def main():
    begin_graphics(800, 600, title='Catch', background=color.YELLOW)
    set_speed(120)

    ball = createBall();

    performance(ball);

def performance(ball):
    x = random_between(0, 800)
    y = random_between(0, 600)
    i = 0
    j = 0

    while True:
        if i == 0:
	    x = incrementX(x)
	    if x >= 800:
	        i = 1
		x = decrementX(800)
	elif i == 1:
	    x = decrementX(x)
	    if x <= 0:
	        i = 0;
		x = incrementX(0)
        if j == 0:
	    y = incrementY(y)
	    if y >= 600:
	        j = 1
		y = decrementY(600)
	elif j == 1:
	    y = decrementY(y)
	    if y <= 0:
	        j = 0;
		y = incrementY(0)
        moveBall(ball, x, y)
	update_when('next_tick')
    end_graphics()

def decrementX(x):
    return x - 4

def incrementX(x):
    return x + 4

def decrementY(y):
    return y - 1

def incrementY(y):
    return y + 1
    

if __name__ == '__main__':
    main();
