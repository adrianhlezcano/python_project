from distutils.core import setup

setup(
      name = 'crazy ball',
      version = '0.0.1',
      py_modules = ['crazy_ball'],
      author = 'Adrian Lezcano',
      author_email = 'adrianhlezcano@gmail.com',
      url = '',
      description = 'Little game using gasp API'
      )
